export default function InsightCard(){return <div />;}
