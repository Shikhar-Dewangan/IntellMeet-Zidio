import { NavLink } from "react-router-dom";
import { LayoutDashboard, Video, Users, FolderKanban, BarChart3, Settings, LogOut } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

const links = [
  ["/dashboard", LayoutDashboard, "Dashboard"],
  ["/meetings", Video, "Meetings"],
  ["/teams", Users, "Teams"],
  ["/projects", FolderKanban, "Projects"],
  ["/analytics", BarChart3, "Analytics"],
  ["/settings", Settings, "Settings"]
];

export default function Sidebar() {
  const { logout } = useAuth();
  return (
    <aside className="sidebar">
      <NavLink to="/dashboard" className="brand sidebar-brand">
        <span className="brand-mark">I</span><span>IntellMeet</span>
      </NavLink>
      <div className="workspace">WORKSPACE</div>
      <nav className="side-links">
        {links.map(([to, Icon, label]) => (
          <NavLink key={to} to={to} className={({ isActive }) => `side-link ${isActive ? "active" : ""}`}>
            <Icon size={19} /><span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <button className="side-link logout-btn" onClick={logout}><LogOut size={19}/><span>Sign out</span></button>
    </aside>
  );
}