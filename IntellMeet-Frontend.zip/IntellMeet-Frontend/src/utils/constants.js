export const APP_NAME = "IntellMeet";
export const MEETING_STATUSES = ["Upcoming", "Completed", "Cancelled"];
export const ROLES = ["Admin", "Member"];
