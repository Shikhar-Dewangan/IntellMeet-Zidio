export const API_CONFIG = { timeout: 10000 };
