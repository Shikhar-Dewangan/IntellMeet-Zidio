# IntellMeet Frontend

Vite + React frontend for **IntellMeet – AI-Powered Enterprise Meeting & Collaboration Platform**.

## Included
- Responsive landing page
- Sign up and sign in flows
- Protected application layout
- Dashboard
- Meetings / meeting room UI
- Chat and collaboration UI
- Tasks / action items
- Teams and projects
- Analytics
- Notifications
- Settings
- Service layer ready for the MERN backend
- LocalStorage demo authentication
- Vite development and production build configuration

## Run
```bash
npm install
npm run dev
```

Open the URL printed by Vite, normally `http://localhost:5173`.

For a production build:
```bash
npm run build
npm run preview
```

The frontend uses mock/local data until the backend API is connected through `VITE_API_URL`.
